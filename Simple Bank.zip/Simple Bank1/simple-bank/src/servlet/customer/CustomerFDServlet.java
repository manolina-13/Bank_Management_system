package servlet.customer;

import db.CustomerDB;
import model.Customer;
import model.FD;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class CustomerFDServlet {

     public static void handle(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        // Authentication Check (redundant if Router does it, but safe)
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("customer") == null) {
            resp.sendRedirect(req.getContextPath() + "/customer/login");
            return;
        }

        if ("GET".equalsIgnoreCase(req.getMethod())) {
            handleGet(req, resp);
        } else if ("POST".equalsIgnoreCase(req.getMethod())) {
            handlePost(req, resp);
        } else {
            resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        }
    }

    private static void handleGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Customer customer = (Customer) session.getAttribute("customer");
        String accountNumber = customer.getAccountNumber();

        // Fetch data for the page
        double balance = CustomerDB.getCustomerBalance(accountNumber);
        List<FD> customerFDs = CustomerDB.getFDsForAccount(accountNumber);

        // Set attributes
        req.setAttribute("balance", balance);
        req.setAttribute("customerFDs", customerFDs);

        // Check for messages from previous POST requests
        if (session.getAttribute("errorMessage") != null) {
            req.setAttribute("errorMessage", session.getAttribute("errorMessage"));
            session.removeAttribute("errorMessage");
        }
        if (session.getAttribute("successMessage") != null) {
             req.setAttribute("successMessage", session.getAttribute("successMessage"));
            session.removeAttribute("successMessage");
        }

        // Forward to JSP
        req.getRequestDispatcher("/WEB-INF/pages/customer/fd.jsp").forward(req, resp);
    }

     private static void handlePost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Customer customer = (Customer) session.getAttribute("customer");
        String accountNumber = customer.getAccountNumber();
        String action = req.getParameter("action"); // Hidden field to identify form

         if (action == null) {
            session.setAttribute("errorMessage", "Invalid form submission.");
            resp.sendRedirect(req.getContextPath() + "/customer/fd");
            return;
        }

        switch (action) {
            case "requestFD":
                handleRequestFD(req, resp, session, accountNumber);
                break;
            case "closeFD":
                handleCloseFD(req, resp, session, accountNumber);
                break;
            default:
                session.setAttribute("errorMessage", "Unknown FD action.");
                resp.sendRedirect(req.getContextPath() + "/customer/fd");
                break;
        }
    }

    // --- POST Action Handlers ---

     private static void handleRequestFD(HttpServletRequest req, HttpServletResponse resp, HttpSession session, String accountNumber) throws IOException {
         String amountStr = req.getParameter("amount");
         String durationStr = req.getParameter("duration"); // Assuming this is in years

         // Validation
         if (isBlank(amountStr) || isBlank(durationStr)) {
             session.setAttribute("errorMessage", "Amount and duration are required for FD request.");
             resp.sendRedirect(req.getContextPath() + "/customer/fd");
             return;
         }

         double amount;
         int durationYears;
         try {
             amount = Double.parseDouble(amountStr);
             durationYears = Integer.parseInt(durationStr);
             if (amount <= 0 || durationYears <= 0) throw new NumberFormatException();
         } catch (NumberFormatException e) {
             session.setAttribute("errorMessage", "Invalid amount or duration.");
             resp.sendRedirect(req.getContextPath() + "/customer/fd");
             return;
         }

         // *** Balance Check BEFORE Request ***
         // This check is placed here as per requirement, before inserting the 'Pending' request.
         // Note: A more robust system might debit upon approval, checking balance then.
         // Following the prompt: check balance now.
         double currentBalance = CustomerDB.getCustomerBalance(accountNumber);
         if (currentBalance < amount) {
             session.setAttribute("errorMessage", String.format("Insufficient balance (%.2f) for FD request of %.2f.", currentBalance, amount));
             resp.sendRedirect(req.getContextPath() + "/customer/fd");
             return;
         }


         // Create the pending FD request in DB
         boolean success = CustomerDB.requestFD(accountNumber, amount, durationYears);

         if (success) {
             session.setAttribute("successMessage", "FD request submitted successfully. Awaiting manager approval.");
         } else {
             session.setAttribute("errorMessage", "Failed to submit FD request. Please try again.");
         }
         resp.sendRedirect(req.getContextPath() + "/customer/fd"); // Redirect back to GET
     }

     private static void handleCloseFD(HttpServletRequest req, HttpServletResponse resp, HttpSession session, String accountNumber) throws IOException {
         String fdIdStr = req.getParameter("fdId");

         if (isBlank(fdIdStr)) {
             session.setAttribute("errorMessage", "FD ID is required to close.");
             resp.sendRedirect(req.getContextPath() + "/customer/fd");
             return;
         }

         int fdId;
         try {
             fdId = Integer.parseInt(fdIdStr);
         } catch (NumberFormatException e) {
             session.setAttribute("errorMessage", "Invalid FD ID format.");
             resp.sendRedirect(req.getContextPath() + "/customer/fd");
             return;
         }

         // The closeFD method internally verifies ownership and status ('Active')
         boolean success = CustomerDB.closeFD(fdId, accountNumber);

          if (success) {
             session.setAttribute("successMessage", "FD ID " + fdId + " closed successfully.");
         } else {
             // Specific error message might have been set by CustomerDB, check session first
             if (session.getAttribute("errorMessage") == null) {
                 session.setAttribute("errorMessage", "Failed to close FD ID " + fdId + ". It might not be active or an error occurred.");
             }
         }
         resp.sendRedirect(req.getContextPath() + "/customer/fd"); // Redirect back to GET
     }


    // Helper method (can be reused from DashboardServlet or put in a common Util)
    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}