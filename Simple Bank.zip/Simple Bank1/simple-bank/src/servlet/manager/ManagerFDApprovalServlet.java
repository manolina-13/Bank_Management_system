package servlet.manager;

import db.ManagerDB;
import model.FD;
import model.Staff; // Manager is Staff

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class ManagerFDApprovalServlet {

      public static void handle(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        // Auth Check
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("manager") == null) {
            resp.sendRedirect(req.getContextPath() + "/manager/login");
            return;
        }

        if ("GET".equalsIgnoreCase(req.getMethod())) {
            handleGet(req, resp);
        } else if ("POST".equalsIgnoreCase(req.getMethod())) {
            handlePost(req, resp);
        } else {
            resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        }
    }

     private static void handleGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Fetch pending FD requests
        List<FD> pendingFDs = ManagerDB.getPendingFDRequests();
        req.setAttribute("pendingFDs", pendingFDs);

         // Check for messages from previous POST requests
        HttpSession session = req.getSession();
        if (session.getAttribute("errorMessage") != null) {
            req.setAttribute("errorMessage", session.getAttribute("errorMessage"));
            session.removeAttribute("errorMessage");
        }
        if (session.getAttribute("successMessage") != null) {
             req.setAttribute("successMessage", session.getAttribute("successMessage"));
            session.removeAttribute("successMessage");
        }

        req.getRequestDispatcher("/WEB-INF/pages/manager/approve_fd.jsp").forward(req, resp);
    }

      private static void handlePost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          HttpSession session = req.getSession();
          Staff manager = (Staff) session.getAttribute("manager"); // Get manager info if needed for logging/audit (not used in DB methods currently)

          String action = req.getParameter("decision"); // "approve" or "reject"
          String fdIdStr = req.getParameter("fdId");

           if (isBlank(action) || isBlank(fdIdStr)) {
             session.setAttribute("errorMessage", "Missing decision or FD ID.");
             resp.sendRedirect(req.getContextPath() + "/manager/approve_fd");
             return;
         }

         int fdId;
         try {
             fdId = Integer.parseInt(fdIdStr);
         } catch (NumberFormatException e) {
             session.setAttribute("errorMessage", "Invalid FD ID format.");
             resp.sendRedirect(req.getContextPath() + "/manager/approve_fd");
             return;
         }

         if ("reject".equals(action)) {
             boolean success = ManagerDB.rejectFD(fdId);
             if (success) {
                 session.setAttribute("successMessage", "FD request ID " + fdId + " rejected successfully.");
             } else {
                 session.setAttribute("errorMessage", "Failed to reject FD request ID " + fdId + ". It might have been already processed.");
             }
             resp.sendRedirect(req.getContextPath() + "/manager/approve_fd"); // Redirect back to GET

         } else if ("approve".equals(action)) {
             // Get approval details from form
             String interestRateStr = req.getParameter("interestRate");

             if (isBlank(interestRateStr)) {
                 session.setAttribute("errorMessage", "Interest rate is required for approval (FD ID: " + fdId + ").");
                 resp.sendRedirect(req.getContextPath() + "/manager/approve_fd");
                 return;
             }

              double interestRate;
              try {
                  interestRate = Double.parseDouble(interestRateStr);
                  if (interestRate < 0) throw new NumberFormatException(); // Interest rate can be 0
              } catch (NumberFormatException e) {
                  session.setAttribute("errorMessage", "Invalid interest rate amount (FD ID: " + fdId + ").");
                  resp.sendRedirect(req.getContextPath() + "/manager/approve_fd");
                  return;
              }

             // Perform the approval transaction in DB
             // ManagerDB.approveFD handles fetching pending FD, checking balance, debiting, and updating status/rate/date.
             boolean success = ManagerDB.approveFD(fdId, interestRate);

             if (success) {
                 session.setAttribute("successMessage", "FD request ID " + fdId + " approved. Customer account debited, FD is now Active.");
             } else {
                  // Specific error message might have been set by ManagerDB (e.g., insufficient balance)
                 if (session.getAttribute("errorMessage") == null) {
                    session.setAttribute("errorMessage", "Failed to approve FD request ID " + fdId + ". Check customer balance or if request is still pending.");
                 }
             }
             resp.sendRedirect(req.getContextPath() + "/manager/approve_fd"); // Redirect back to GET
         } else {
              session.setAttribute("errorMessage", "Invalid decision specified.");
              resp.sendRedirect(req.getContextPath() + "/manager/approve_fd");
         }
      }


    // Helper method
    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}