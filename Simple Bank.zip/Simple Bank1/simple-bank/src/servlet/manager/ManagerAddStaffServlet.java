package servlet.manager;

import auth.AuthHelper;
import db.StaffDB; // Need to use StaffDB for staff operations
import model.Staff;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List; // Import List


public class ManagerAddStaffServlet {

      public static void handle(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        // Auth Check
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("manager") == null) {
            resp.sendRedirect(req.getContextPath() + "/manager/login");
            return;
        }

        if ("GET".equalsIgnoreCase(req.getMethod())) {
            handleGet(req, resp);
        } else if ("POST".equalsIgnoreCase(req.getMethod())) {
            handlePost(req, resp);
        } else {
            resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        }
    }

     private static void handleGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Fetch all staff to display in the table
        List<Staff> allStaff = StaffDB.getAllStaff();
        req.setAttribute("allStaff", allStaff);

         // Check for messages from previous POST requests
        HttpSession session = req.getSession();
        if (session.getAttribute("errorMessage") != null) {
            req.setAttribute("errorMessage", session.getAttribute("errorMessage"));
            session.removeAttribute("errorMessage");
        }
        if (session.getAttribute("successMessage") != null) {
             req.setAttribute("successMessage", session.getAttribute("successMessage"));
            session.removeAttribute("successMessage");
        }

        req.getRequestDispatcher("/WEB-INF/pages/manager/add_staff.jsp").forward(req, resp);
    }

      private static void handlePost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          HttpSession session = req.getSession();

          // Get parameters from the Add Staff form
          String name = req.getParameter("name");
          String mobile = req.getParameter("mobile");
          String password = req.getParameter("password");

           if (isBlank(name) || isBlank(mobile) || isBlank(password)) {
             session.setAttribute("errorMessage", "Name, Mobile, and Password are required to add staff.");
             resp.sendRedirect(req.getContextPath() + "/manager/add_staff"); // Redirect back to GET
             return;
         }

         // Basic mobile number format check
         if (!mobile.trim().matches("\\d{10}")) {
              session.setAttribute("errorMessage", "Mobile number must be 10 digits.");
              resp.sendRedirect(req.getContextPath() + "/manager/add_staff");
              return;
         }

         // Check if staff (either STAFF or MANAGER) with this mobile already exists
         if (StaffDB.staffExistsByMobile(mobile.trim())) {
              session.setAttribute("errorMessage", "A staff member with this mobile number already exists.");
              resp.sendRedirect(req.getContextPath() + "/manager/add_staff");
              return;
         }


         // Hash the password
         String passwordHash = AuthHelper.hashPassword(password);

         // Create the staff member in DB
         boolean success = StaffDB.createStaff(name.trim(), mobile.trim(), passwordHash);

          if (success) {
             session.setAttribute("successMessage", "New staff member (" + name.trim() + ", Mobile: " + mobile.trim() + ") added successfully.");
         } else {
             session.setAttribute("errorMessage", "Failed to add staff member. Please try again.");
         }
         resp.sendRedirect(req.getContextPath() + "/manager/add_staff"); // Redirect back to GET
      }


    // Helper method (can be reused or put in a common Util)
    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}