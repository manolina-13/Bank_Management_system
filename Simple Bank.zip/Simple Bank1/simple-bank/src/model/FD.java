package model;

// Corresponds to FD table: id, accno, created_at, start_date, amount, duration_years, status, interest_rate
public class FD {
    private int id;
    private String accNumber;
    private String createdAt; // Timestamp of the request submission
    private String startDate; // Date FD becomes active (YYYY-MM-DD)
    private double amount;
    private int durationYears; // Duration in years
    private String status; // e.g., 'Pending', 'Active', 'Closed', 'Rejected'
    private double interestRate; // Annual rate set by manager (using double for consistency with Loan/amount)

    // Constructor
    public FD(int id, String accNumber, String createdAt, String startDate, double amount, int durationYears, String status, double interestRate) {
        this.id = id;
        this.accNumber = accNumber;
        this.createdAt = createdAt;
        this.startDate = startDate;
        this.amount = amount;
        this.durationYears = durationYears;
        this.status = status;
        this.interestRate = interestRate;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getAccNumber() {
        return accNumber;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getStartDate() {
        return startDate;
    }

    public double getAmount() {
        return amount;
    }

    public int getDurationYears() {
        return durationYears;
    }

    public String getStatus() {
        return status;
    }

    public double getInterestRate() {
        return interestRate;
    }

    // You might want setters if you plan to modify objects in memory, but for this design, fetching new ones is fine.
}