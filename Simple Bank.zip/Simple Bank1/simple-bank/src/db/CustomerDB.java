package db;

import model.Customer;
import model.Grievance;
import model.Loan;
import model.Transaction;
import model.FD;

import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.math.BigDecimal; // For precise financial calculations
import java.math.RoundingMode; // For precise financial calculations


public class CustomerDB {

    // --- Customer Authentication & Details ---

    public static Optional<Customer> validateCustomerLogin(String accountNumber, String passwordHash) {
        String sql = "SELECT id, name, mobile, email, accountno, password FROM Customer WHERE accountno = ? AND password = ? LIMIT 1";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, accountNumber);
            pstmt.setString(2, passwordHash); // Compare against the stored hash
            rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(new Customer(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("mobile"),
                        rs.getString("email"),
                        rs.getString("accountno"),
                        rs.getString("password") // Stored hash
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error validating customer login: " + e.getMessage());
        } finally {
            DatabaseUtil.closeQuietly(rs);
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return Optional.empty();
    }

     public static Optional<Customer> getCustomerByAccountNumber(String accountNumber) {
        String sql = "SELECT id, name, mobile, email, accountno, password FROM Customer WHERE accountno = ? LIMIT 1";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, accountNumber);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                 return Optional.of(new Customer(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("mobile"),
                        rs.getString("email"),
                        rs.getString("accountno"),
                        rs.getString("password") // Stored hash
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting customer by account number: " + e.getMessage());
        } finally {
            DatabaseUtil.closeQuietly(rs);
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return Optional.empty();
    }


    public static double getCustomerBalance(String accountNumber) {
        // Balance isn't stored directly in Customer table per schema.
        // It must be calculated from Transactions or assumed to be managed elsewhere.
        // For simplicity, let's assume a function to calculate it, or return 0.
        // A more realistic approach involves summing transactions.
        // Let's simulate by summing transaction amounts for this account.

        String sql = "SELECT " +
                     "  COALESCE(SUM(CASE WHEN to_acc = ? THEN amount ELSE 0 END), 0) - " +
                     "  COALESCE(SUM(CASE WHEN from_acc = ? THEN amount ELSE 0 END), 0) as balance " +
                     "FROM Transactions " +
                     "WHERE to_acc = ? OR from_acc = ?";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        double balance = 0.0;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, accountNumber);
            pstmt.setString(2, accountNumber);
            pstmt.setString(3, accountNumber);
            pstmt.setString(4, accountNumber);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                balance = rs.getDouble("balance");
            }
        } catch (SQLException e) {
            System.err.println("Error calculating customer balance: " + e.getMessage());
            // Return 0 or throw exception depending on desired handling
        } finally {
            DatabaseUtil.closeQuietly(rs);
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return balance;
    }


    public static boolean updateCustomerPassword(String accountNumber, String newPasswordHash) {
        String sql = "UPDATE Customer SET password = ? WHERE accountno = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean success = false;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, newPasswordHash);
            pstmt.setString(2, accountNumber);
            int rowsAffected = pstmt.executeUpdate();
            success = rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating customer password: " + e.getMessage());
        } finally {
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return success;
    }

    // --- Transactions ---

    public static List<Transaction> getTransactionsForAccount(String accountNumber) {
        List<Transaction> transactions = new ArrayList<>();
        // Get transactions where the account is either sender or receiver
        // Ordering by ID descending to get newest first
        String sql = "SELECT id, accno, amount, to_acc, from_acc, type, date(Timestamp) as date, time(Timestamp) as time FROM Transactions WHERE accno = ? OR to_acc = ? OR from_acc = ? ORDER BY id DESC";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, accountNumber);
             pstmt.setString(2, accountNumber); // Match to_acc
              pstmt.setString(3, accountNumber); // Match from_acc

            rs = pstmt.executeQuery();

            while (rs.next()) {
                 // Reconstruct timestamp if needed, or use separate date/time if DB stores them
                 String dateTime = rs.getString("date") + " " + rs.getString("time"); // Adjust based on actual DB column name/format
                transactions.add(new Transaction(
                        rs.getInt("id"),
                        accountNumber, // The context account
                        rs.getDouble("amount"),
                        rs.getString("to_acc"),
                        rs.getString("from_acc"),
                        rs.getString("type"),
                        dateTime // Pass the timestamp string
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting transactions for account: " + e.getMessage());
        } finally {
            DatabaseUtil.closeQuietly(rs);
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return transactions;
    }

    /**
     * Performs a transfer between two accounts. Assumes sufficient funds check happens before calling.
     * Adds two transaction records (one debit, one credit).
     */
    public static boolean performTransfer(String fromAccount, String toAccount, double amount) {
       String sqlInsert = "INSERT INTO Transactions (accno, amount, to_acc, from_acc, type, Timestamp) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
       Connection conn = null;
       PreparedStatement pstmtDebit = null;
       PreparedStatement pstmtCredit = null;
       boolean success = false;

       try {
           conn = DatabaseUtil.getConnection();
           conn.setAutoCommit(false); // Start transaction

           // 1. Record Debit from sender
           pstmtDebit = conn.prepareStatement(sqlInsert);
           pstmtDebit.setString(1, fromAccount); // Primary account for this record
           pstmtDebit.setDouble(2, amount);
           pstmtDebit.setString(3, toAccount);
           pstmtDebit.setString(4, fromAccount);
           pstmtDebit.setString(5, "Transfer Out"); // Or just "Transfer"
           pstmtDebit.executeUpdate();

           // 2. Record Credit to receiver
           pstmtCredit = conn.prepareStatement(sqlInsert);
           pstmtCredit.setString(1, toAccount); // Primary account for this record
           pstmtCredit.setDouble(2, amount);
           pstmtCredit.setString(3, toAccount);
           pstmtCredit.setString(4, fromAccount);
           pstmtCredit.setString(5, "Transfer In"); // Or just "Transfer"
           pstmtCredit.executeUpdate();

           conn.commit(); // Commit transaction
           success = true;

       } catch (SQLException e) {
           System.err.println("Error performing transfer: " + e.getMessage());
           if (conn != null) {
               try {
                   conn.rollback();
                   System.err.println("Transfer transaction rolled back.");
               } catch (SQLException ex) {
                   System.err.println("Error rolling back transfer transaction: " + ex.getMessage());
               }
           }
       } finally {
           DatabaseUtil.closeQuietly(pstmtDebit);
            DatabaseUtil.closeQuietly(pstmtCredit);
           if (conn != null) {
               try {
                   conn.setAutoCommit(true); // Restore auto-commit mode
               } catch (SQLException e) { /* ignore */ }
               DatabaseUtil.closeQuietly(conn);
           }
       }
       return success;
   }

    // --- Loans ---

    public static List<Loan> getActiveLoansForAccount(String accountNumber) {
        List<Loan> loans = new ArrayList<>();
        // Assuming 'active' means not fully repaid. This might require checking related 'Loan Repaid' transactions.
        // Simplified: Get all loans for the account. Repayment status handled in servlet/JSP via calculation.
        String sql = "SELECT id, amount, accno, int_rate, date, duration FROM Loan WHERE accno = ? ORDER BY date DESC";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, accountNumber);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                loans.add(new Loan(
                        rs.getInt("id"),
                        rs.getDouble("amount"),
                        rs.getString("accno"),
                        rs.getDouble("int_rate"),
                        rs.getString("date"), // Assuming date is stored as text (YYYY-MM-DD)
                        rs.getInt("duration")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting loans for account: " + e.getMessage());
        } finally {
            DatabaseUtil.closeQuietly(rs);
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return loans;
    }


    public static Optional<Loan> getLoanById(int loanId) {
        String sql = "SELECT id, amount, accno, int_rate, date, duration FROM Loan WHERE id = ? LIMIT 1";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, loanId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(new Loan(
                    rs.getInt("id"),
                    rs.getDouble("amount"),
                    rs.getString("accno"),
                    rs.getDouble("int_rate"),
                    rs.getString("date"),
                    rs.getInt("duration")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting loan by ID: " + e.getMessage());
        } finally {
           DatabaseUtil.closeQuietly(rs);
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return Optional.empty();
    }


    /**
     * Records a loan repayment transaction. Assumes sufficient funds check happens before calling.
     * Returns true on success.
     */
    public static boolean repayLoan(String accountNumber, int loanId, double repayAmount) {
        String sqlInsert = "INSERT INTO Transactions (accno, amount, from_acc, type, Timestamp) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)";
        // Note: `to_acc` is NULL for loan repayment (money leaves bank system concept)
        // We also need to potentially mark the Loan as 'repaid' or delete it if fully paid.
        // For simplicity, we only add the transaction record. Full repayment logic is complex.

        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean success = false;

        try {
            conn = DatabaseUtil.getConnection();
            conn.setAutoCommit(false); // Start transaction

            // Insert transaction record
            pstmt = conn.prepareStatement(sqlInsert);
            pstmt.setString(1, accountNumber);
            pstmt.setDouble(2, repayAmount);
            pstmt.setString(3, accountNumber); // Money comes from the customer's account
            pstmt.setString(4, "Loan Repaid (ID: " + loanId + ")"); // Type indicates repayment and loan ID
            pstmt.executeUpdate();

            // Simplification: We are NOT updating the Loan table status here.
            // A real system would check if repayAmount covers the outstanding balance
            // and update the Loan status or delete the Loan record if fully paid.

            conn.commit();
            success = true;

        } catch (SQLException e) {
            System.err.println("Error recording loan repayment: " + e.getMessage());
             if (conn != null) {
               try {
                   conn.rollback();
                   System.err.println("Loan repayment transaction rolled back.");
               } catch (SQLException ex) {
                   System.err.println("Error rolling back loan repayment transaction: " + ex.getMessage());
               }
           }
        } finally {
            DatabaseUtil.closeQuietly(pstmt);
             if (conn != null) {
               try {
                   conn.setAutoCommit(true); // Restore auto-commit mode
               } catch (SQLException e) { /* ignore */ }
               DatabaseUtil.closeQuietly(conn);
           }
        }
        return success;
    }

     /**
      * Calculates the amount needed to repay a loan based on the provided formula.
      * Uses BigDecimal for precision.
      */
     public static BigDecimal calculateLoanRepayAmount(Loan loan) {
         LocalDate creationDate = LocalDate.parse(loan.getDateCreated()); // Assumes YYYY-MM-DD format
         LocalDate today = LocalDate.now();

         // Use BigDecimal for principal and rates
         BigDecimal principal = BigDecimal.valueOf(loan.getAmount());
         BigDecimal normalAnnualRatePercent = BigDecimal.valueOf(loan.getInterestRate()); // e.g., 5.0 for 5%

         long totalDaysPassed = ChronoUnit.DAYS.between(creationDate, today);
         // Convert total days passed to years (can be fractional) for comparison and calculation
         // Using 365.25 days per year average for BigDecimal calculation
         BigDecimal daysInYear = new BigDecimal("365.25");
         BigDecimal totalYearsPassed = new BigDecimal(totalDaysPassed).divide(daysInYear, 10, RoundingMode.HALF_UP); // 10 decimal places for intermediate calc

         BigDecimal loanDurationYears = BigDecimal.valueOf(loan.getDurationYears());

         BigDecimal effectiveAnnualRatePercent;

         if (totalYearsPassed.compareTo(loanDurationYears) <= 0) {
             // Within normal duration
             effectiveAnnualRatePercent = normalAnnualRatePercent;
         } else {
             // Overdue - calculate penalty
             BigDecimal extraTimeYears = totalYearsPassed.subtract(loanDurationYears);
             // Calculate number of full half-years passed in extra time
             // extraTimeYears / 0.5 = extraTimeYears * 2
             BigDecimal halfYearsPassedDecimal = extraTimeYears.multiply(new BigDecimal("2"));
             // Floor this value to get number of full half-year periods for penalty
             long halfYearsPassed = halfYearsPassedDecimal.setScale(0, RoundingMode.FLOOR).longValue();

             // Penalty is 1% per full half-year overdue
             BigDecimal penaltyPercent = new BigDecimal(halfYearsPassed).multiply(BigDecimal.ONE); // 1% is 1.0

             effectiveAnnualRatePercent = normalAnnualRatePercent.add(penaltyPercent);
             System.out.println("Loan ID " + loan.getId() + " overdue. Extra Half-Years: " + halfYearsPassed + ", Penalty: " + penaltyPercent + "%, Effective Rate: " + effectiveAnnualRatePercent + "%");
         }

         // Calculate quarterly compounding
         // Ensure rate is not negative if penalties somehow exceed initial rate (unlikely)
         if (effectiveAnnualRatePercent.compareTo(BigDecimal.ZERO) < 0) {
             effectiveAnnualRatePercent = BigDecimal.ZERO;
         }

         BigDecimal annualRateDecimal = effectiveAnnualRatePercent.divide(new BigDecimal("100"), 10, RoundingMode.HALF_UP);
         BigDecimal quarterlyRateDecimal = annualRateDecimal.divide(new BigDecimal("4"), 10, RoundingMode.HALF_UP);

         // Number of quarters = total years passed * 4
         // Use double for Math.pow, accepting potential minor precision loss at exponentiation stage, or use a loop for BigDecimal power.
         // Using Math.pow for simplicity as requested.
         double numberOfQuarters = totalYearsPassed.multiply(new BigDecimal("4")).doubleValue();

         // final_amount = principal * (1 + quarterly_rate) ^ quarters
         double base = BigDecimal.ONE.add(quarterlyRateDecimal).doubleValue();
         double finalAmountDouble = principal.doubleValue() * Math.pow(base, numberOfQuarters);

         // Return as BigDecimal rounded to 2 decimal places (currency)
         return BigDecimal.valueOf(finalAmountDouble).setScale(2, RoundingMode.HALF_UP);
     }


    // --- Grievances ---

    public static boolean createGrievance(String accountNumber, String complaint) {
        // Status defaults to 'Pending', remarks null initially
        String sql = "INSERT INTO Grievance (accno, complain, status, Timestamp) VALUES (?, ?, 'Pending', CURRENT_TIMESTAMP)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean success = false;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, accountNumber);
            pstmt.setString(2, complaint);
            int rowsAffected = pstmt.executeUpdate();
            success = rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error creating grievance: " + e.getMessage());
        } finally {
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return success;
    }

    public static List<Grievance> getGrievancesForAccount(String accountNumber) {
        List<Grievance> grievances = new ArrayList<>();
        String sql = "SELECT id, accno, complain, status, remarks, Timestamp FROM Grievance WHERE accno = ? ORDER BY id DESC";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, accountNumber);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                grievances.add(new Grievance(
                        rs.getInt("id"),
                        rs.getString("accno"),
                        rs.getString("complain"),
                        rs.getString("status"),
                        rs.getString("remarks"),
                        rs.getString("Timestamp") // Get timestamp as string
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting grievances for account: " + e.getMessage());
        } finally {
            DatabaseUtil.closeQuietly(rs);
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return grievances;
    }
    public static boolean requestFD(String accountNumber, double amount, int durationYears) {
        // status='Pending', start_date=NULL, interest_rate=NULL initially
        String sql = "INSERT INTO FD (accno, created_at, amount, duration_years, status) VALUES (?, CURRENT_TIMESTAMP, ?, ?, 'Pending')";
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean success = false;

        // Basic validation (more can be done in servlet)
        if (amount <= 0 || durationYears <= 0) {
            System.err.println("Invalid FD request parameters: amount or duration <= 0.");
            return false;
        }

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, accountNumber);
            pstmt.setDouble(2, amount);
            pstmt.setInt(3, durationYears);
            int rowsAffected = pstmt.executeUpdate();
            success = rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error creating FD request: " + e.getMessage());
        } finally {
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return success;
    }

    /**
     * Gets all FDs (pending, active, closed, rejected) for a specific account.
     */
    public static List<FD> getFDsForAccount(String accountNumber) {
        List<FD> fds = new ArrayList<>();
        // Order by created_at descending to see newest first
        String sql = "SELECT id, accno, created_at, start_date, amount, duration_years, status, interest_rate FROM FD WHERE accno = ? ORDER BY created_at DESC";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, accountNumber);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                fds.add(new FD(
                        rs.getInt("id"),
                        rs.getString("accno"),
                        rs.getString("created_at"),
                        rs.getString("start_date"), // Can be null for pending/rejected
                        rs.getDouble("amount"),
                        rs.getInt("duration_years"),
                        rs.getString("status"),
                        rs.getDouble("interest_rate") // Can be null for pending/rejected
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting FDs for account: " + e.getMessage());
        } finally {
            DatabaseUtil.closeQuietly(rs);
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return fds;
    }

     /**
     * Gets a specific FD by its ID.
     */
    public static Optional<FD> getFDById(int fdId) {
        String sql = "SELECT id, accno, created_at, start_date, amount, duration_years, status, interest_rate FROM FD WHERE id = ? LIMIT 1";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, fdId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                 return Optional.of(new FD(
                        rs.getInt("id"),
                        rs.getString("accno"),
                        rs.getString("created_at"),
                        rs.getString("start_date"),
                        rs.getDouble("amount"),
                        rs.getInt("duration_years"),
                        rs.getString("status"),
                        rs.getDouble("interest_rate")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting FD by ID: " + e.getMessage());
        } finally {
           DatabaseUtil.closeQuietly(rs);
            DatabaseUtil.closeQuietly(pstmt);
            DatabaseUtil.closeQuietly(conn);
        }
        return Optional.empty();
    }


    /**
     * Closes an active FD, calculates interest, and credits the account.
     */
    public static boolean closeFD(int fdId, String accountNumber) {
        // Need to fetch FD details first
        Optional<FD> fdOpt = getFDById(fdId);
        if (fdOpt.isEmpty() || !fdOpt.get().getAccNumber().equals(accountNumber) || !fdOpt.get().getStatus().equals("Active")) {
            System.err.println("FD ID " + fdId + " not found, doesn't belong to account " + accountNumber + ", or is not Active.");
            return false;
        }

        FD fd = fdOpt.get();
        BigDecimal principal = BigDecimal.valueOf(fd.getAmount());
        double annualRate = fd.getInterestRate();
        String startDateStr = fd.getStartDate(); // This should not be null for 'Active' FD

        if (startDateStr == null) {
             System.err.println("CRITICAL: Active FD ID " + fdId + " has no start date.");
             return false; // Should not happen if approval logic is correct
        }

        LocalDate startDate = LocalDate.parse(startDateStr); // Assumes YYYY-MM-DD
        LocalDate today = LocalDate.now();
        LocalDate maturityDate = startDate.plusYears(fd.getDurationYears());

        double effectiveAnnualRate = annualRate;
        // Check for early closure
        if (today.isBefore(maturityDate)) {
            effectiveAnnualRate = Math.max(0, annualRate - 1.5); // Apply 1.5% penalty, minimum 0%
            System.out.println("FD ID " + fdId + " closed early. Applied rate penalty. Effective rate: " + effectiveAnnualRate + "%");
        } else {
             System.out.println("FD ID " + fdId + " closed after maturity. Applied full rate: " + effectiveAnnualRate + "%");
        }


        // Calculate interest based on days passed and effective annual rate (simple interest for simplicity as per example, not compound)
        // If quarterly compounding is needed like Loan, use that logic instead.
        // Let's stick to simple interest for FD for contrast/simplicity unless specified.
        // Using simple interest calculation: Principal * Rate * Time
        // Time = days passed / 365.25
        long totalDaysPassed = ChronoUnit.DAYS.between(startDate, today);
         // Ensure totalDaysPassed is at least 0, although logically it should be > 0 for an active FD.
         totalDaysPassed = Math.max(0, totalDaysPassed);


        BigDecimal annualRateDecimal = BigDecimal.valueOf(effectiveAnnualRate).divide(new BigDecimal("100"), 10, RoundingMode.HALF_UP);
        BigDecimal daysInYear = new BigDecimal("365.25");
        BigDecimal timeInYears = new BigDecimal(totalDaysPassed).divide(daysInYear, 10, RoundingMode.HALF_UP);

        BigDecimal interest = principal.multiply(annualRateDecimal).multiply(timeInYears);

        // Ensure interest is not negative (shouldn't be with rate >= 0)
        interest = interest.max(BigDecimal.ZERO);

        BigDecimal totalPayout = principal.add(interest).setScale(2, RoundingMode.HALF_UP);

        System.out.println("FD ID " + fdId + " closure payout calculation: Principal=" + principal + ", Days Held=" + totalDaysPassed + ", Effective Rate=" + effectiveAnnualRate + "%, Calculated Interest=" + interest.setScale(2, RoundingMode.HALF_UP) + ", Total Payout=" + totalPayout);


        String sqlUpdateFDStatus = "UPDATE FD SET status = 'Closed' WHERE id = ? AND status = 'Active'"; // Ensure it was active
        String sqlInsertTransaction = "INSERT INTO Transactions (accno, amount, to_acc, from_acc, type, Timestamp) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
        Connection conn = null;
        PreparedStatement pstmtUpdate = null;
        PreparedStatement pstmtInsertTxn = null;
        boolean success = false;

        try {
            conn = DatabaseUtil.getConnection();
            conn.setAutoCommit(false); // Start transaction

            // 1. Update FD status
            pstmtUpdate = conn.prepareStatement(sqlUpdateFDStatus);
            pstmtUpdate.setInt(1, fdId);
            int rowsUpdated = pstmtUpdate.executeUpdate();

            if (rowsUpdated == 0) {
                 System.err.println("Failed to update FD status to Closed (ID " + fdId + "). It might not have been Active.");
                 conn.rollback();
                 return false;
            }

            // 2. Insert transaction record (Credit to customer account)
            pstmtInsertTxn = conn.prepareStatement(sqlInsertTransaction);
            pstmtInsertTxn.setString(1, accountNumber);
            pstmtInsertTxn.setBigDecimal(2, totalPayout); // Use BigDecimal for amount
            pstmtInsertTxn.setString(3, accountNumber); // Money goes TO the customer's account
            pstmtInsertTxn.setString(4, null); // Money comes FROM the bank system
            pstmtInsertTxn.setString(5, "FD Closed (ID: " + fdId + ")");
            pstmtInsertTxn.executeUpdate();

            conn.commit(); // Commit transaction
            success = true;

        } catch (SQLException e) {
            System.err.println("Error closing FD (ID " + fdId + "): " + e.getMessage());
             if (conn != null) {
               try {
                   conn.rollback();
                   System.err.println("FD closure transaction rolled back.");
               } catch (SQLException ex) {
                   System.err.println("Error rolling back FD closure transaction: " + ex.getMessage());
               }
           }
        } finally {
            DatabaseUtil.closeQuietly(pstmtUpdate);
            DatabaseUtil.closeQuietly(pstmtInsertTxn);
             if (conn != null) {
               try {
                   conn.setAutoCommit(true); // Restore auto-commit mode
               } catch (SQLException e) { /* ignore */ }
               DatabaseUtil.closeQuietly(conn);
           }
        }
        return success;
    }
}